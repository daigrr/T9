This game doesn’t have a name and it’s pretty incomplete, but have fun playing anyways! We had no clue how to use Unity. Developed over the course of 24 hours for the T9 Hacks hackathon http://www.t9hacks.org

Arrow keys/WASD to move, mouse to look around, space to jump, left mouse/left ctrl to pick up

Developed by Cicada Scott, Scarlett Harris, Ashley Beavers, and Dai Lin

Unity Assets:
	Ben3d Crate
	https://www.assetstore.unity3d.com/en/#!/content/7548
	Catana and Crowbar Pack
	https://www.assetstore.unity3d.com/en/#!/content/8893
	Decrepit Dungeon LITE
	https://www.assetstore.unity3d.com/en/#!/content/33936
	Handpainted Keys
	https://www.assetstore.unity3d.com/en/#!/content/42044
	Unity Standard Assets
	https://www.assetstore.unity3d.com/en/#!/content/32351

Music: 
	Nine Inch Nails
	http://www.nin.wiki/Ghosts_I-IV

Sound effects:
	https://www.audioblocks.com
	http://soundbible.com

Textures:
	http://www.textures.com/


